<?php
$link=mysqli_connect("localhost:3308","root","");
mysqli_select_db($link,"online_quiz"); 
?>